# lanzador.ps1
# Proyecto: TU_IA_LOCAL — Creado por SecTF Lab
# Ventana gráfica sencilla (sin consola visible) para usuarios sin conocimientos técnicos.
# Comprueba Node.js y Ollama; si falta alguno, ofrece un botón para instalarlo en segundo
# plano. Si todo está listo, abre la web directamente en la pantalla de "elegir IA".

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Detectar si estamos ejecutando PS1 o EXE compilado con PS2EXE
if ($MyInvocation.MyCommand.CommandType -eq "ExternalScript") {
    # Ejecutando lanzador.ps1
    $CarpetaProyecto = $PSScriptRoot
}
else {
    # Ejecutando Asistente de IA.exe
    $CarpetaProyecto = [System.AppContext]::BaseDirectory.TrimEnd('\')
}

$VersionMinimaNode = 18
$UrlApp = "http://localhost:4321"
#$CarpetaProyecto = Split-Path -Parent $MyInvocation.MyCommand.Path


# ---------- Crear acceso directo en el escritorio ----------

function Crear-AccesoDirecto {

    try {

        # Solo crear acceso directo cuando estamos ejecutando el EXE
        if ($MyInvocation.MyCommand.CommandType -eq "ExternalScript") {
            return
        }

        # Ruta del propio EXE
        $RutaExe = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName

        # Escritorio del usuario
        $Escritorio = [Environment]::GetFolderPath("Desktop")

        # Ruta del acceso directo
        $RutaAcceso = Join-Path $Escritorio "Asistente de IA.lnk"

        # Crear acceso directo
        $Shell = New-Object -ComObject WScript.Shell
        $Shortcut = $Shell.CreateShortcut($RutaAcceso)

        # El acceso directo apunta directamente al EXE
        $Shortcut.TargetPath = $RutaExe

        # Carpeta de trabajo
        $Shortcut.WorkingDirectory = $CarpetaProyecto

        # Descripción
        $Shortcut.Description = "Asistente de IA - SecTF Lab"

        # El propio EXE contiene el icono
        $Shortcut.IconLocation = "$RutaExe,0"

        $Shortcut.Save()

    }
    catch {
        # No detener la aplicación si falla la creación
    }
}

Crear-AccesoDirecto


# ---------- Elevación: instalar software requiere permisos de administrador ----------

function Test-EsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}

if (-not (Test-EsAdmin)) {
    # Nos relanzamos a nosotros mismos con permisos de administrador.
    # Esto muestra UNA vez el cuadro nativo de Windows "¿Permitir que esta app haga
    # cambios?" — no es una ventana de cmd/PowerShell, es el diálogo de seguridad
    # estándar de Windows, y es inevitable para instalar programas.

    $exe = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName

    if ($exe -match 'powershell') {
        Start-Process powershell -ArgumentList @(
            "-NoProfile",
            "-WindowStyle",
            "Hidden",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            "`"$PSCommandPath`""
        ) -Verb RunAs
    } else {
        Start-Process $exe -Verb RunAs
    }

    exit
}


# ---------- Comprobaciones ----------

function Test-NodeInstalado {
    try {
        $v = node -v 2>$null

        if ($LASTEXITCODE -ne 0 -or -not $v) {
            return $false
        }

        return ([int]($v.TrimStart('v').Split('.')[0])) -ge $VersionMinimaNode
    }
    catch {
        return $false
    }
}

function Test-OllamaInstalado {
    try {
        ollama --version *> $null
        return ($LASTEXITCODE -eq 0)
    }
    catch {
        return $false
    }
}

function Refrescar-Path {
    $env:Path =
        [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
        [System.Environment]::GetEnvironmentVariable("Path", "User")
}


# ---------- Ventana ----------

$form = New-Object System.Windows.Forms.Form
$form.Text = "Asistente de IA · SecTF Lab"
$form.Size = New-Object System.Drawing.Size(430, 240)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(16, 20, 27)

$lblTitulo = New-Object System.Windows.Forms.Label
$lblTitulo.Text = "Asistente de IA"
$lblTitulo.Font = New-Object System.Drawing.Font(
    "Segoe UI",
    15,
    [System.Drawing.FontStyle]::Bold
)
$lblTitulo.ForeColor = [System.Drawing.Color]::White
$lblTitulo.AutoSize = $true
$lblTitulo.Location = New-Object System.Drawing.Point(24, 20)
$form.Controls.Add($lblTitulo)

$lblEstado = New-Object System.Windows.Forms.Label
$lblEstado.Text = "Comprobando tu equipo…"
$lblEstado.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblEstado.ForeColor = [System.Drawing.Color]::FromArgb(230, 233, 238)
$lblEstado.Size = New-Object System.Drawing.Size(380, 70)
$lblEstado.Location = New-Object System.Drawing.Point(24, 65)
$form.Controls.Add($lblEstado)

$barra = New-Object System.Windows.Forms.ProgressBar
$barra.Style = "Marquee"
$barra.MarqueeAnimationSpeed = 30
$barra.Size = New-Object System.Drawing.Size(380, 10)
$barra.Location = New-Object System.Drawing.Point(24, 140)
$form.Controls.Add($barra)

$btnAccion = New-Object System.Windows.Forms.Button
$btnAccion.Text = "Instalar"
$btnAccion.Size = New-Object System.Drawing.Size(160, 36)
$btnAccion.Location = New-Object System.Drawing.Point(24, 155)
$btnAccion.BackColor = [System.Drawing.Color]::FromArgb(242, 166, 90)
$btnAccion.ForeColor = [System.Drawing.Color]::FromArgb(26, 18, 6)
$btnAccion.FlatStyle = "Flat"
$btnAccion.FlatAppearance.BorderSize = 0
$btnAccion.Font = New-Object System.Drawing.Font(
    "Segoe UI",
    9.5,
    [System.Drawing.FontStyle]::Bold
)
$btnAccion.Visible = $false
$form.Controls.Add($btnAccion)

$lblFirma = New-Object System.Windows.Forms.Label
$lblFirma.Text = "SecTF Lab"
$lblFirma.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$lblFirma.ForeColor = [System.Drawing.Color]::FromArgb(137, 148, 163)
$lblFirma.AutoSize = $true
$lblFirma.Location = New-Object System.Drawing.Point(24, 195)
$form.Controls.Add($lblFirma)


# ---------- Máquina de estados ----------

$script:trabajo = $null
$script:paso = "comprobar-node"

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 500


function Avanzar {

    switch ($script:paso) {

        "comprobar-node" {

            $barra.Visible = $true
            $btnAccion.Visible = $false

            $lblEstado.Text = "Comprobando si Node.js está instalado…"

            if (Test-NodeInstalado) {

                $script:paso = "comprobar-ollama"
                Avanzar

            } else {

                $barra.Visible = $false

                $lblEstado.Text = "Falta un componente necesario para poder usar la IA. Pulsa Instalar y espera: se hace solo."

                $btnAccion.Text = "Instalar"
                $btnAccion.Tag = "node"
                $btnAccion.Visible = $true
            }
        }


        "instalando-node" {

            $lblEstado.Text = "Instalando… esto puede tardar uno o dos minutos. Puedes esperar tranquilamente."

            $barra.Visible = $true
            $btnAccion.Visible = $false

            $script:trabajo = Start-Job -ScriptBlock {

                winget install --id OpenJS.NodeJS.LTS -e --silent `
                    --accept-source-agreements `
                    --accept-package-agreements
            }

            $script:paso = "esperando-node"

            $timer.Start()
        }


        "comprobar-ollama" {

            $barra.Visible = $true
            $btnAccion.Visible = $false

            $lblEstado.Text = "Comprobando si la IA local está instalada…"

            if (Test-OllamaInstalado) {

                $script:paso = "lanzar-app"
                Avanzar

            } else {

                $barra.Visible = $false

                $lblEstado.Text = "Falta instalar la IA. Pulsa Instalar y espera: se hace solo."

                $btnAccion.Text = "Instalar"
                $btnAccion.Tag = "ollama"
                $btnAccion.Visible = $true
            }
        }


        "instalando-ollama" {

            $lblEstado.Text = "Instalando la IA en segundo plano. Esto puede tardar unos minutos…"

            $barra.Visible = $true
            $btnAccion.Visible = $false

            $script:trabajo = Start-Job -ScriptBlock {

                winget install --id Ollama.Ollama -e --silent `
                    --accept-source-agreements `
                    --accept-package-agreements
            }

            $script:paso = "esperando-ollama"

            $timer.Start()
        }


        "lanzar-app" {

            $lblEstado.Text = "Todo listo. Abriendo el asistente…"

            $barra.Visible = $true
            $btnAccion.Visible = $false

            $enMarcha = $false

            try {

                Invoke-WebRequest `
                    -Uri $UrlApp `
                    -UseBasicParsing `
                    -TimeoutSec 1 | Out-Null

                $enMarcha = $true

            }
            catch {

                $enMarcha = $false
            }


            if (-not $enMarcha) {

                Start-Process `
                    -FilePath "node" `
                    -ArgumentList "server.js" `
                    -WorkingDirectory $CarpetaProyecto `
                    -WindowStyle Hidden

                Start-Sleep -Seconds 2
            }


            Start-Process "$UrlApp/?inicio=modelos"

            Start-Sleep -Milliseconds 800

            $form.Close()
        }
    }
}


$btnAccion.Add_Click({

    if ($btnAccion.Tag -eq "node") {

        $script:paso = "instalando-node"

    }
    elseif ($btnAccion.Tag -eq "ollama") {

        $script:paso = "instalando-ollama"
    }

    Avanzar
})


$timer.Add_Tick({

    if ($script:trabajo -and $script:trabajo.State -ne "Running") {

        $timer.Stop()

        Receive-Job $script:trabajo | Out-Null

        Remove-Job $script:trabajo -Force

        $script:trabajo = $null

        Refrescar-Path


        if ($script:paso -eq "esperando-node") {

            if (Test-NodeInstalado) {

                $script:paso = "comprobar-ollama"

            }
            else {

                $barra.Visible = $false

                $lblEstado.Text = "No se pudo instalar Node.js automáticamente. Avisa a soporte técnico."

                return
            }

        }
        elseif ($script:paso -eq "esperando-ollama") {

            if (Test-OllamaInstalado) {

                $script:paso = "lanzar-app"

            }
            else {

                $barra.Visible = $false

                $lblEstado.Text = "No se pudo instalar la IA automáticamente. Avisa a soporte técnico."

                return
            }
        }

        Avanzar
    }
})


$form.Add_Shown({
    Avanzar
})

[void]$form.ShowDialog()