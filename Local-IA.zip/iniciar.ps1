# iniciar.ps1
# Proyecto: tu_ia_local — Creado por SecTF Lab
# Comprueba que Node.js 18+ esté instalado; si no, lo instala con winget;
# después instala dependencias (si hace falta) y arranca tu_ia_local.

$ErrorActionPreference = "Stop"
$VersionMinima = 18

function Obtener-VersionNode {
    try {
        $salida = node -v 2>$null
        if ($LASTEXITCODE -ne 0 -or -not $salida) { return $null }
        return [int]($salida.TrimStart('v').Split('.')[0])
    } catch {
        return $null
    }
}

function Refrescar-Path {
    # winget actualiza el PATH del sistema, pero la sesión de PowerShell actual
    # no se entera hasta que lo recargamos manualmente.
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
                [System.Environment]::GetEnvironmentVariable("Path", "User")
}

Write-Host "== tu_ia_local · SecTF Lab ==" -ForegroundColor DarkYellow
Write-Host "== comprobando Node.js ==" -ForegroundColor Cyan

$versionActual = Obtener-VersionNode

if ($null -ne $versionActual -and $versionActual -ge $VersionMinima) {
    Write-Host "Node.js ya está instalado (v$versionActual). Continúo." -ForegroundColor Green
}
else {
    if ($null -ne $versionActual) {
        Write-Host "Hay Node.js v$versionActual instalado, pero se necesita v$VersionMinima o superior." -ForegroundColor Yellow
    } else {
        Write-Host "Node.js no está instalado en este equipo." -ForegroundColor Yellow
    }

    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Write-Host "No se encontró 'winget'. Instala Node.js manualmente desde https://nodejs.org y vuelve a ejecutar este script." -ForegroundColor Red
        Read-Host "Pulsa Enter para salir"
        exit 1
    }

    Write-Host "Instalando Node.js LTS con winget (esto puede tardar un par de minutos)..." -ForegroundColor Cyan
    winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements

    if ($LASTEXITCODE -ne 0) {
        Write-Host "La instalación de Node.js falló (código $LASTEXITCODE)." -ForegroundColor Red
        Read-Host "Pulsa Enter para salir"
        exit 1
    }

    Refrescar-Path
    $versionActual = Obtener-VersionNode

    if ($null -eq $versionActual) {
        Write-Host "Node.js se instaló, pero esta ventana no lo detecta todavía." -ForegroundColor Yellow
        Write-Host "Cierra esta ventana, abre PowerShell de nuevo y vuelve a ejecutar este script." -ForegroundColor Yellow
        Read-Host "Pulsa Enter para salir"
        exit 1
    }

    Write-Host "Node.js v$versionActual instalado correctamente." -ForegroundColor Green
}

Write-Host ""
Write-Host "== Preparando tu_ia_local ==" -ForegroundColor Cyan

$carpetaProyecto = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $carpetaProyecto

if (-not (Test-Path "node_modules")) {
    Write-Host "Instalando dependencias (npm install)..." -ForegroundColor Cyan
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "npm install falló." -ForegroundColor Red
        Read-Host "Pulsa Enter para salir"
        exit 1
    }
} else {
    Write-Host "Dependencias ya instaladas." -ForegroundColor Green
}

Write-Host ""
Write-Host "== Arrancando el servidor en http://localhost:4321 ==" -ForegroundColor Cyan
Start-Process "http://localhost:4321"
npm start
