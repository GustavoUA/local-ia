@echo off
REM iniciar.bat — doble clic para arrancar tu_ia_local.
REM Proyecto: tu_ia_local — Creado por SecTF Lab
REM Llama a iniciar.ps1 saltando la política de ejecución solo para este proceso.

powershell -NoProfile -ExecutionPolicy Bypass -File "%iniciar.ps1"
pause
