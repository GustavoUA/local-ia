// app.js — Proyecto: tu_ia_local — Creado por SecTF Lab
// lógica de la interfaz. Habla siempre con nuestro propio servidor local (server.js),
// nunca directamente con Ollama, para poder ejecutar comandos de instalación/descarga.

const $ = (sel) => document.querySelector(sel);

const vistas = {
  menu: $('#vista-menu'),
  instalar: $('#vista-instalar'),
  modelos: $('#vista-modelos'),
  chat: $('#vista-chat'),
};

function mostrarVista(nombre) {
  Object.values(vistas).forEach((v) => v.classList.add('oculta'));
  vistas[nombre].classList.remove('oculta');
}

// --- Entrada directa: si el lanzador abre la web con ?inicio=modelos,
//     nos saltamos el menú y vamos derechos a elegir IA. ---
const parametros = new URLSearchParams(location.search);
if (parametros.get('inicio') === 'modelos') {
  $('#panel').classList.remove('oculto');
  mostrarVista('modelos');
  cargarModelos();
}

// --- Abrir panel desde el hero ---
$('#btn-abrir-panel').addEventListener('click', () => {
  $('#panel').classList.remove('oculto');
  mostrarVista('menu');
  $('#panel').scrollIntoView({ behavior: 'smooth' });
});

// --- Menú principal ---
document.querySelectorAll('#vista-menu .menu-item').forEach((item) => {
  item.addEventListener('click', () => {
    const accion = item.dataset.accion;
    if (accion === 'instalar') {
      mostrarVista('instalar');
      comprobarEstado();
    } else if (accion === 'conversar') {
      mostrarVista('modelos');
      cargarModelos();
    }
  });
});

// --- Botones "volver" ---
document.querySelectorAll('[data-volver]').forEach((btn) => {
  btn.addEventListener('click', () => mostrarVista(btn.dataset.volver));
});

/* ============ VISTA 1: INSTALAR ============ */

async function comprobarEstado() {
  $('#txt-instalado').textContent = 'comprobando…';
  $('#txt-corriendo').textContent = 'comprobando…';
  $('#punto-instalado').className = 'estado-punto';
  $('#punto-corriendo').className = 'estado-punto';

  try {
    const r = await fetch('/api/status');
    const data = await r.json();

    $('#txt-instalado').textContent = data.instalado ? 'sí' : 'no';
    $('#punto-instalado').className = 'estado-punto ' + (data.instalado ? 'ok' : 'no');

    $('#txt-corriendo').textContent = data.corriendo ? 'sí' : 'no';
    $('#punto-corriendo').className = 'estado-punto ' + (data.corriendo ? 'ok' : 'no');

    $('#btn-instalar').disabled = data.instalado;
    $('#btn-instalar').textContent = data.instalado ? 'Ya está instalado' : 'Instalar ahora';
  } catch (e) {
    $('#txt-instalado').textContent = 'error';
    $('#txt-corriendo').textContent = 'error';
  }
}

$('#btn-comprobar').addEventListener('click', comprobarEstado);

$('#btn-instalar').addEventListener('click', async () => {
  const log = $('#log-instalar');
  log.classList.remove('oculta');
  log.textContent = 'Iniciando instalación…\n';
  $('#btn-instalar').disabled = true;

  try {
    const r = await fetch('/api/install', { method: 'POST' });
    const reader = r.body.getReader();
    const decoder = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      log.textContent += decoder.decode(value);
      log.scrollTop = log.scrollHeight;
    }
  } catch (e) {
    log.textContent += '\n[ERROR] ' + e.message;
  }

  comprobarEstado();
});

/* ============ VISTA 2: MODELOS ============ */

async function cargarModelos() {
  $('#aviso-sin-servicio').classList.add('oculta');
  const listaInstalados = $('#lista-instalados');
  const listaSugeridos = $('#lista-sugeridos');
  listaInstalados.innerHTML = '';
  listaSugeridos.innerHTML = '';
  $('#sin-instalados').classList.add('oculta');

  // Modelos ya instalados
  const rInst = await fetch('/api/models');
  const dInst = await rInst.json();

  if (!dInst.ok) {
    $('#aviso-sin-servicio').classList.remove('oculta');
  }

  if (dInst.ok && dInst.modelos.length > 0) {
    dInst.modelos.forEach((m, i) => {
      const li = document.createElement('li');
      li.className = 'menu-item';
      li.innerHTML = `
        <span class="menu-num">${i + 1}</span>
        <div class="menu-texto">
          <span class="menu-titulo">${m.name}</span>
          <span class="menu-desc">${formatearTamano(m.size)}</span>
        </div>
        <span class="menu-flecha">&gt;</span>
      `;
      li.addEventListener('click', () => iniciarChat(m.name));
      listaInstalados.appendChild(li);
    });
  } else {
    $('#sin-instalados').classList.remove('oculta');
  }

  // Modelos sugeridos para descargar
  const rSug = await fetch('/api/suggested');
  const dSug = await rSug.json();

  dSug.modelos.forEach((m) => {
    const li = document.createElement('li');
    li.className = 'menu-item';
    if (m.instalado) li.dataset.desactivado = 'true';
    li.innerHTML = `
      <div class="menu-texto">
        <span class="menu-titulo">${m.nombre}</span>
        <span class="menu-desc">${m.descripcion} · <code style="font-family:var(--mono)">${m.tag}</code></span>
      </div>
      ${m.instalado
        ? '<span class="menu-desc">ya instalado</span>'
        : `<button class="menu-accion" data-tag="${m.tag}">Descargar</button>`}
    `;
    listaSugeridos.appendChild(li);
  });

  listaSugeridos.querySelectorAll('.menu-accion').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      descargarModelo(btn.dataset.tag, btn);
    });
  });
}

function formatearTamano(bytes) {
  if (!bytes) return '';
  const gb = bytes / (1024 ** 3);
  return gb >= 1 ? `${gb.toFixed(1)} GB` : `${(bytes / (1024 ** 2)).toFixed(0)} MB`;
}

async function descargarModelo(tag, boton) {
  const log = $('#log-descarga');
  log.classList.remove('oculta');
  log.textContent = `Descargando ${tag}…\n`;
  boton.disabled = true;
  boton.textContent = 'Descargando…';

  try {
    const r = await fetch('/api/pull', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ modelo: tag }),
    });
    const reader = r.body.getReader();
    const decoder = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      log.textContent += decoder.decode(value);
      log.scrollTop = log.scrollHeight;
    }
  } catch (e) {
    log.textContent += '\n[ERROR] ' + e.message;
  }

  cargarModelos();
}

$('#btn-iniciar-servicio').addEventListener('click', async () => {
  const boton = $('#btn-iniciar-servicio');
  const txt = $('#txt-iniciar-servicio');
  boton.disabled = true;
  boton.textContent = 'Iniciando…';
  txt.textContent = 'Esto puede tardar unos segundos.';

  try {
    const r = await fetch('/api/start-ollama', { method: 'POST' });
    const data = await r.json();
    if (data.ok) {
      txt.textContent = 'Servicio iniciado.';
      await cargarModelos();
    } else {
      txt.textContent = data.error || 'No se pudo iniciar el servicio. Prueba a abrir la aplicación Ollama manualmente.';
    }
  } catch (e) {
    txt.textContent = 'Error al iniciar el servicio: ' + e.message;
  }

  boton.disabled = false;
  boton.textContent = 'Iniciar servicio de Ollama';
});

/* ============ VISTA 3: CHAT ============ */

let modeloActual = null;
let historial = [];

function iniciarChat(nombreModelo) {
  modeloActual = nombreModelo;
  historial = [];
  $('#chat-modelo-nombre').textContent = nombreModelo;
  $('#chat-mensajes').innerHTML = '';
  mostrarVista('chat');
  $('#chat-input').focus();
}

$('#chat-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = $('#chat-input');
  const texto = input.value.trim();
  if (!texto || !modeloActual) return;

  agregarMensaje('usuario', texto);
  historial.push({ role: 'user', content: texto });
  input.value = '';

  const burbujaIA = agregarMensaje('ia', '');
  let textoIA = '';

  try {
    const r = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ modelo: modeloActual, mensajes: historial }),
    });

    const reader = r.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // Ollama envía NDJSON: una línea = un objeto JSON
      const lineas = buffer.split('\n');
      buffer = lineas.pop(); // guarda la línea incompleta para el siguiente chunk

      for (const linea of lineas) {
        if (!linea.trim()) continue;
        try {
          const obj = JSON.parse(linea);
          if (obj.message && obj.message.content) {
            textoIA += obj.message.content;
            burbujaIA.textContent = textoIA;
            $('#chat-mensajes').scrollTop = $('#chat-mensajes').scrollHeight;
          }
        } catch (err) {
          // línea no parseable, la ignoramos
        }
      }
    }
  } catch (err) {
    burbujaIA.textContent = 'No se pudo contactar con el modelo: ' + err.message;
  }

  historial.push({ role: 'assistant', content: textoIA });
});

function agregarMensaje(tipo, texto) {
  const div = document.createElement('div');
  div.className = 'msg ' + tipo;
  div.textContent = texto;
  $('#chat-mensajes').appendChild(div);
  $('#chat-mensajes').scrollTop = $('#chat-mensajes').scrollHeight;
  return div;
}
