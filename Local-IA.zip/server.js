// server.js
// Proyecto: tu_ia_local — Creado por SecTF Lab
// Servidor local que hace de puente entre la web y la IA instalada en tu PC (Ollama).
// Se ejecuta con: npm start   (arranca en http://localhost:4321)

const express = require('express');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = 4321;
const OLLAMA_API = 'http://127.0.0.1:11434';

// Modelos "recomendados" que se pueden ofrecer para instalar si el usuario no tiene nada aún.
// Puedes añadir/quitar los que quieras; el nombre debe ser un tag válido de la librería de Ollama.
const MODELOS_SUGERIDOS = [
  { tag: 'qwen2.5:1.5b',  nombre: 'Qwen 2.5 · 1.5B', descripcion: 'Muy ligero, ideal para equipos modestos' },
  { tag: 'qwen2.5:3b',    nombre: 'Qwen 2.5 · 3B',   descripcion: 'Equilibrio entre velocidad y calidad' },
  { tag: 'qwen2.5:7b',    nombre: 'Qwen 2.5 · 7B',   descripcion: 'Más capaz, necesita más RAM/VRAM' },
  { tag: 'deepseek-r1:1.5b', nombre: 'DeepSeek-R1 · 1.5B', descripcion: 'Razonamiento, versión ligera' },
  { tag: 'deepseek-r1:7b',   nombre: 'DeepSeek-R1 · 7B',   descripcion: 'Razonamiento, más potente' },
  { tag: 'llama3.2:1b',   nombre: 'Llama 3.2 · 1B',  descripcion: 'Rapidísimo, respuestas más simples' },
  { tag: 'llama3.2:3b',   nombre: 'Llama 3.2 · 3B',  descripcion: 'Buen equilibrio general' },
  { tag: 'gemma2:2b',     nombre: 'Gemma 2 · 2B',    descripcion: 'Ligero, de Google' },
];

// Ejecuta un comando y hace streaming de su salida como texto plano a la respuesta HTTP.
function ejecutarConStreaming(res, comando, args) {
  res.writeHead(200, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Transfer-Encoding': 'chunked',
    'Cache-Control': 'no-cache',
  });

  const proceso = spawn(comando, args, { shell: true, windowsHide: true });

  proceso.stdout.on('data', (data) => res.write(data.toString()));
  proceso.stderr.on('data', (data) => res.write(data.toString()));

  proceso.on('error', (err) => {
    res.write(`\n[ERROR] No se pudo ejecutar el comando: ${err.message}\n`);
    res.end();
  });

  proceso.on('close', (code) => {
    res.write(`\n[FIN] Proceso terminado con código ${code}\n`);
    res.end();
  });
}

// --- Estado: ¿está Ollama instalado y corriendo? ---
app.get('/api/status', async (req, res) => {
  const instalado = await new Promise((resolve) => {
    const p = spawn('ollama', ['--version'], { shell: true, windowsHide: true });
    let salida = false;
    p.on('error', () => resolve(false));
    p.stdout.on('data', () => (salida = true));
    p.on('close', (code) => resolve(salida || code === 0));
  });

  let corriendo = false;
  try {
    const r = await fetch(`${OLLAMA_API}/api/tags`);
    corriendo = r.ok;
  } catch (e) {
    corriendo = false;
  }

  res.json({ instalado, corriendo, plataforma: os.platform() });
});

// --- Instalar Ollama vía PowerShell (Windows) ---
app.post('/api/install', (req, res) => {
  if (os.platform() === 'win32') {
    // winget es la forma recomendada y oficial en Windows 10/11
    ejecutarConStreaming(
      res,
      'powershell.exe',
      ['-NoProfile', '-Command', '"winget install --id Ollama.Ollama -e --accept-source-agreements --accept-package-agreements"']
    );
  } else if (os.platform() === 'darwin') {
    ejecutarConStreaming(res, 'sh', ['-c', '"curl -fsSL https://ollama.com/install.sh | sh"']);
  } else {
    ejecutarConStreaming(res, 'sh', ['-c', '"curl -fsSL https://ollama.com/install.sh | sh"']);
  }
});

// --- Arrancar el servicio de Ollama (ollama serve) si no está corriendo ---
app.post('/api/start-ollama', async (req, res) => {
  try {
    const proceso = spawn('ollama', ['serve'], {
      shell: true,
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
    });
    proceso.unref();
    proceso.on('error', () => {
      // Si el binario no existe, el error llega aquí de forma asíncrona;
      // el bucle de comprobación de abajo lo acabará reportando como "no responde".
    });
  } catch (e) {
    return res.json({ ok: false, error: 'No se pudo lanzar "ollama serve": ' + e.message });
  }

  // "ollama serve" tarda un instante en levantar la API, así que reintentamos unos segundos.
  const maxIntentos = 12;
  for (let i = 0; i < maxIntentos; i++) {
    await new Promise((r) => setTimeout(r, 500));
    try {
      const r2 = await fetch(`${OLLAMA_API}/api/tags`);
      if (r2.ok) return res.json({ ok: true });
    } catch (e) {
      // seguimos intentando
    }
  }

  res.json({
    ok: false,
    error: 'Ollama no respondió a tiempo. Puede que ya haya una instancia bloqueada o que necesite iniciarse manualmente.',
  });
});

// --- Listar modelos instalados ---
app.get('/api/models', async (req, res) => {
  try {
    const r = await fetch(`${OLLAMA_API}/api/tags`);
    if (!r.ok) throw new Error('Ollama no responde');
    const data = await r.json();
    res.json({ ok: true, modelos: data.models || [] });
  } catch (e) {
    res.json({ ok: false, error: 'No se pudo conectar con Ollama. ¿Está iniciado? (ollama serve)', modelos: [] });
  }
});

// --- Modelos sugeridos para descargar, marcando cuáles ya están instalados ---
app.get('/api/suggested', async (req, res) => {
  let instalados = [];
  try {
    const r = await fetch(`${OLLAMA_API}/api/tags`);
    if (r.ok) {
      const data = await r.json();
      instalados = (data.models || []).map((m) => m.name);
    }
  } catch (e) {
    // Ollama no corriendo: seguimos, simplemente ninguno aparecerá como instalado
  }

  const lista = MODELOS_SUGERIDOS.map((m) => ({
    ...m,
    instalado: instalados.includes(m.tag),
  }));

  res.json({ modelos: lista });
});

// --- Descargar (pull) un modelo, con streaming del progreso ---
app.post('/api/pull', (req, res) => {
  const { modelo } = req.body;
  if (!modelo) return res.status(400).json({ error: 'Falta el nombre del modelo' });
  ejecutarConStreaming(res, 'ollama', ['pull', modelo]);
});

// --- Chat: reenvía la conversación a Ollama y hace streaming de la respuesta ---
app.post('/api/chat', async (req, res) => {
  const { modelo, mensajes } = req.body;
  if (!modelo || !mensajes) return res.status(400).json({ error: 'Falta modelo o mensajes' });

  try {
    const respuestaOllama = await fetch(`${OLLAMA_API}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: modelo, messages: mensajes, stream: true }),
    });

    res.writeHead(200, {
      'Content-Type': 'text/plain; charset=utf-8',
      'Transfer-Encoding': 'chunked',
      'Cache-Control': 'no-cache',
    });

    for await (const chunk of respuestaOllama.body) {
      res.write(chunk);
    }
    res.end();
  } catch (e) {
    res.write(JSON.stringify({ error: 'No se pudo contactar con Ollama: ' + e.message }));
    res.end();
  }
});

app.listen(PORT, () => {
  console.log(`\n  Servidor listo -> http://localhost:${PORT}\n`);
});
